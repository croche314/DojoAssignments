mathlib = require('./mathlib')();
mathlib.add(5,4);
mathlib.multiply(4,10);
mathlib.square(9);
mathlib.random(1,100);